import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kioku/widgets/custom_edit_text.dart';

void main() {
  group('CustomEditText', () {
    testWidgets('deve renderizar o campo de texto', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomEditText(),
          ),
        ),
      );

      expect(find.byType(TextFormField), findsOneWidget);
    });

    testWidgets('deve exibir hintText quando fornecido', (WidgetTester tester) async {
      const hintText = 'Digite seu nome';

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomEditText(
              hintText: hintText,
            ),
          ),
        ),
      );

      expect(find.text(hintText), findsOneWidget);
    });

    testWidgets('deve aceitar e exibir texto digitado', (WidgetTester tester) async {
      final controller = TextEditingController();

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomEditText(
              controller: controller,
            ),
          ),
        ),
      );

      await tester.enterText(find.byType(TextFormField), 'Texto de teste');
      expect(controller.text, 'Texto de teste');
    });

    testWidgets('deve validar texto quando validator é fornecido', (WidgetTester tester) async {
      final controller = TextEditingController();
      String? validator(String? value) {
        if (value == null || value.isEmpty) {
          return 'Campo obrigatório';
        }
        return null;
      }

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Form(
              child: CustomEditText(
                controller: controller,
                validator: validator,
              ),
            ),
          ),
        ),
      );

      final formField = tester.widget<TextFormField>(find.byType(TextFormField));
      expect(formField.validator?.call(''), 'Campo obrigatório');
      expect(formField.validator?.call('texto'), null);
    });

    testWidgets('deve usar keyboardType correto', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomEditText(
              keyboardType: TextInputType.emailAddress,
            ),
          ),
        ),
      );

      final textField = tester.widget<TextFormField>(find.byType(TextFormField));
      expect(textField.keyboardType, TextInputType.emailAddress);
    });

    testWidgets('deve ser readOnly quando especificado', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomEditText(
              readOnly: true,
            ),
          ),
        ),
      );

      final textField = tester.widget<TextFormField>(find.byType(TextFormField));
      expect(textField.readOnly, isTrue);
    });

    testWidgets('deve usar maxLines quando especificado', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomEditText(
              maxLines: 5,
            ),
          ),
        ),
      );

      final textField = tester.widget<TextFormField>(find.byType(TextFormField));
      expect(textField.maxLines, 5);
    });

    testWidgets('deve ocultar texto quando obscureText é true', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomEditText(
              obscureText: true,
            ),
          ),
        ),
      );

      final textField = tester.widget<TextFormField>(find.byType(TextFormField));
      expect(textField.obscureText, isTrue);
    });

    testWidgets('deve chamar onTap quando fornecido', (WidgetTester tester) async {
      bool wasTapped = false;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomEditText(
              onTap: () {
                wasTapped = true;
              },
            ),
          ),
        ),
      );

      await tester.tap(find.byType(TextFormField));
      expect(wasTapped, isTrue);
    });

    testWidgets('deve exibir suffixIcon quando fornecido', (WidgetTester tester) async {
      const icon = Icon(Icons.search);

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomEditText(
              suffixIcon: icon,
            ),
          ),
        ),
      );

      expect(find.byIcon(Icons.search), findsOneWidget);
    });
  });
}

