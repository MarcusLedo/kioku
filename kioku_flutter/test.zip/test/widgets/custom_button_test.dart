import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kioku/widgets/custom_button.dart';
import 'package:kioku/core/app_export.dart';

void main() {
  group('CustomButton', () {
    testWidgets('deve renderizar o texto do botão', (WidgetTester tester) async {
      const text = 'Clique aqui';
      
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomButton(
              text: text,
              width: 100,
            ),
          ),
        ),
      );

      expect(find.text(text), findsOneWidget);
    });

    testWidgets('deve chamar onPressed quando clicado', (WidgetTester tester) async {
      bool wasPressed = false;
      
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomButton(
              text: 'Teste',
              width: 100,
              onPressed: () {
                wasPressed = true;
              },
            ),
          ),
        ),
      );

      await tester.tap(find.byType(OutlinedButton));
      await tester.pump();

      expect(wasPressed, isTrue);
    });

    testWidgets('não deve chamar onPressed quando null', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomButton(
              text: 'Teste',
              width: 100,
              onPressed: null,
            ),
          ),
        ),
      );

      await tester.tap(find.byType(OutlinedButton));
      await tester.pump();

      // Não deve lançar exceção
      expect(find.byType(OutlinedButton), findsOneWidget);
    });

    testWidgets('deve usar cores customizadas quando fornecidas', (WidgetTester tester) async {
      const textColor = Colors.red;
      const borderColor = Colors.blue;
      const backgroundColor = Colors.green;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomButton(
              text: 'Teste',
              width: 100,
              textColor: textColor,
              borderColor: borderColor,
              backgroundColor: backgroundColor,
            ),
          ),
        ),
      );

      final button = tester.widget<OutlinedButton>(find.byType(OutlinedButton));
      expect(button.style?.backgroundColor?.resolve({}), backgroundColor);
    });

    testWidgets('deve usar largura e altura customizadas', (WidgetTester tester) async {
      const width = 200.0;
      const height = 50.0;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomButton(
              text: 'Teste',
              width: width,
              height: height,
            ),
          ),
        ),
      );

      final container = tester.widget<Container>(find.byType(Container).first);
      expect(container.width, width);
      expect(container.height, height);
    });

    testWidgets('deve usar padding e margin customizados', (WidgetTester tester) async {
      const padding = EdgeInsets.all(20);
      const margin = EdgeInsets.all(10);

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomButton(
              text: 'Teste',
              width: 100,
              padding: padding,
              margin: margin,
            ),
          ),
        ),
      );

      final container = tester.widget<Container>(find.byType(Container).first);
      expect(container.margin, margin);
    });

    testWidgets('deve usar borderRadius customizado', (WidgetTester tester) async {
      const borderRadius = 20.0;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomButton(
              text: 'Teste',
              width: 100,
              borderRadius: borderRadius,
            ),
          ),
        ),
      );

      final button = tester.widget<OutlinedButton>(find.byType(OutlinedButton));
      final shape = button.style?.shape as RoundedRectangleBorder?;
      expect(shape?.borderRadius, BorderRadius.circular(borderRadius));
    });
  });
}

