import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kioku/widgets/custom_image_view.dart';
import 'package:kioku/core/app_export.dart';

void main() {
  group('CustomImageView', () {
    testWidgets('deve usar imagem padrão quando imagePath é null', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomImageView(),
          ),
        ),
      );

      // Deve renderizar sem erros
      expect(find.byType(CustomImageView), findsOneWidget);
    });

    testWidgets('deve usar imagem padrão quando imagePath é vazio', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomImageView(
              imagePath: '',
            ),
          ),
        ),
      );

      // Deve renderizar sem erros
      expect(find.byType(CustomImageView), findsOneWidget);
    });

    testWidgets('deve renderizar com altura e largura customizadas', (WidgetTester tester) async {
      const height = 100.0;
      const width = 200.0;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomImageView(
              imagePath: ImageConstant.imgImageNotFound,
              height: height,
              width: width,
            ),
          ),
        ),
      );

      // Deve renderizar sem erros
      expect(find.byType(CustomImageView), findsOneWidget);
    });

    testWidgets('deve chamar onTap quando fornecido', (WidgetTester tester) async {
      bool wasTapped = false;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomImageView(
              imagePath: ImageConstant.imgImageNotFound,
              onTap: () {
                wasTapped = true;
              },
            ),
          ),
        ),
      );

      await tester.tap(find.byType(InkWell));
      expect(wasTapped, isTrue);
    });

    testWidgets('deve usar alignment quando fornecido', (WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomImageView(
              imagePath: ImageConstant.imgImageNotFound,
              alignment: Alignment.center,
            ),
          ),
        ),
      );

      expect(find.byType(Align), findsOneWidget);
    });

    testWidgets('deve usar margin quando fornecido', (WidgetTester tester) async {
      const margin = EdgeInsets.all(10);

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomImageView(
              imagePath: ImageConstant.imgImageNotFound,
              margin: margin,
            ),
          ),
        ),
      );

      final padding = tester.widget<Padding>(find.byType(Padding));
      expect(padding.padding, margin);
    });

    testWidgets('deve usar radius quando fornecido', (WidgetTester tester) async {
      const radius = BorderRadius.all(Radius.circular(10));

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomImageView(
              imagePath: ImageConstant.imgImageNotFound,
              radius: radius,
            ),
          ),
        ),
      );

      expect(find.byType(ClipRRect), findsOneWidget);
    });

    testWidgets('deve usar border quando fornecido', (WidgetTester tester) async {
      const border = Border.all(color: Colors.black, width: 2);

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: CustomImageView(
              imagePath: ImageConstant.imgImageNotFound,
              border: border,
            ),
          ),
        ),
      );

      expect(find.byType(Container), findsWidgets);
    });
  });

  group('ImageTypeExtension', () {
    test('deve identificar SVG local corretamente', () {
      expect('image.svg'.imageType, ImageType.svg);
    });

    test('deve identificar PNG local corretamente', () {
      expect('image.png'.imageType, ImageType.png);
    });

    test('deve identificar imagem de rede corretamente', () {
      expect('https://example.com/image.jpg'.imageType, ImageType.network);
    });

    test('deve identificar SVG de rede corretamente', () {
      expect('https://example.com/image.svg'.imageType, ImageType.networkSvg);
    });

    test('deve identificar arquivo local corretamente', () {
      expect('file:///path/to/image.jpg'.imageType, ImageType.file);
    });
  });
}

