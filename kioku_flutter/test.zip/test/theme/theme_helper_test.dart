import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kioku/theme/theme_helper.dart';

void main() {
  group('ThemeHelper', () {
    test('deve retornar instância de LightCodeColors', () {
      final themeHelper = ThemeHelper();
      final colors = themeHelper.themeColor();
      
      expect(colors, isA<LightCodeColors>());
    });

    test('deve retornar ThemeData válido', () {
      final themeHelper = ThemeHelper();
      final theme = themeHelper.themeData();
      
      expect(theme, isA<ThemeData>());
    });

    test('themeColor deve retornar a mesma instância', () {
      final themeHelper = ThemeHelper();
      final colors1 = themeHelper.themeColor();
      final colors2 = themeHelper.themeColor();
      
      expect(colors1, equals(colors2));
    });

    test('themeData deve retornar ThemeData com ColorScheme', () {
      final themeHelper = ThemeHelper();
      final theme = themeHelper.themeData();
      
      expect(theme.colorScheme, isNotNull);
    });
  });

  group('LightCodeColors', () {
    test('deve ter todas as cores definidas', () {
      final colors = LightCodeColors();
      
      expect(colors.white_A700, isNotNull);
      expect(colors.cyan_900, isNotNull);
      expect(colors.gray_50, isNotNull);
      expect(colors.cyan_A700, isNotNull);
      expect(colors.transparentCustom, isNotNull);
      expect(colors.greenCustom, isNotNull);
      expect(colors.whiteCustom, isNotNull);
      expect(colors.redCustom, isNotNull);
      expect(colors.greyCustom, isNotNull);
      expect(colors.grey200, isNotNull);
      expect(colors.grey100, isNotNull);
    });

    test('deve retornar cores com valores corretos', () {
      final colors = LightCodeColors();
      
      expect(colors.cyan_900.value, 0xFF005F6B);
      expect(colors.cyan_A700.value, 0xFF00B4CC);
      expect(colors.white_A700.value, 0xFFFFFFFF);
      expect(colors.gray_50.value, 0xFFF8F9FA);
    });

    test('deve retornar cores customizadas corretas', () {
      final colors = LightCodeColors();
      
      expect(colors.transparentCustom, equals(colors.transparentCustom));
      expect(colors.greenCustom, isNotNull);
      expect(colors.redCustom, isNotNull);
    });
  });

  group('ColorSchemes', () {
    test('deve ter lightCodeColorScheme definido', () {
      expect(ColorSchemes.lightCodeColorScheme, isNotNull);
    });
  });
}

