import 'dart:ui';

import 'package:flutter_test/flutter_test.dart';
import 'package:kioku/theme/text_style_helper.dart';

void main() {
  group('TextStyleHelper', () {
    test('deve retornar a mesma instância (singleton)', () {
      final instance1 = TextStyleHelper.instance;
      final instance2 = TextStyleHelper.instance;
      
      expect(instance1, equals(instance2));
    });

    test('deve ter title20RegularRoboto definido', () {
      final helper = TextStyleHelper.instance;
      final style = helper.title20RegularRoboto;
      
      expect(style, isNotNull);
      expect(style.fontSize, isNotNull);
      expect(style.fontWeight, FontWeight.w400);
      expect(style.fontFamily, 'Roboto');
    });

    test('deve ter title20BoldOpenSans definido', () {
      final helper = TextStyleHelper.instance;
      final style = helper.title20BoldOpenSans;
      
      expect(style, isNotNull);
      expect(style.fontSize, isNotNull);
      expect(style.fontWeight, FontWeight.w700);
      expect(style.fontFamily, 'Open Sans');
    });

    test('deve ter body15RegularOpenSans definido', () {
      final helper = TextStyleHelper.instance;
      final style = helper.body15RegularOpenSans;
      
      expect(style, isNotNull);
      expect(style.fontSize, isNotNull);
      expect(style.fontWeight, FontWeight.w400);
      expect(style.fontFamily, 'Open Sans');
    });

    test('deve ter body14LightOpenSans definido', () {
      final helper = TextStyleHelper.instance;
      final style = helper.body14LightOpenSans;
      
      expect(style, isNotNull);
      expect(style.fontSize, isNotNull);
      expect(style.fontWeight, FontWeight.w300);
      expect(style.fontFamily, 'Open Sans');
    });

    test('deve ter body18RegularOpenSans definido', () {
      final helper = TextStyleHelper.instance;
      final style = helper.body18RegularOpenSans;
      
      expect(style, isNotNull);
      expect(style.fontSize, isNotNull);
      expect(style.fontWeight, FontWeight.w400);
      expect(style.fontFamily, 'Open Sans');
    });

    test('deve ter textStyle5 definido', () {
      final helper = TextStyleHelper.instance;
      final style = helper.textStyle5;
      
      expect(style, isNotNull);
    });
  });
}

