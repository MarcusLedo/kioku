# Testes Unitários - Kioku

Este diretório contém todos os testes unitários do projeto Kioku.

## Estrutura de Testes

```
test/
├── services/              # Testes dos serviços Supabase
│   ├── supabase_service_test.dart
│   ├── supabase_auth_service_test.dart
│   ├── supabase_deck_service_test.dart
│   ├── supabase_flashcard_service_test.dart
│   ├── supabase_study_service_test.dart
│   └── supabase_storage_service_test.dart
├── widgets/              # Testes dos widgets customizados
│   ├── custom_button_test.dart
│   ├── custom_edit_text_test.dart
│   └── custom_image_view_test.dart
├── theme/                # Testes dos helpers de tema
│   ├── theme_helper_test.dart
│   └── text_style_helper_test.dart
├── utils/                # Testes dos utilitários
│   ├── size_utils_test.dart
│   └── image_constant_test.dart
└── widget_test.dart      # Teste principal do app
```

## Como Executar os Testes

### Executar todos os testes
```bash
flutter test
```

### Executar um arquivo de teste específico
```bash
flutter test test/services/supabase_auth_service_test.dart
```

### Executar testes com cobertura
```bash
flutter test --coverage
```

### Executar testes em modo verbose
```bash
flutter test --verbose
```

## Dependências de Teste

As seguintes dependências são usadas para testes:

- `flutter_test`: Framework de testes do Flutter (incluído no SDK)
- `mocktail`: Biblioteca para criar mocks (adicionada ao pubspec.yaml)

## Instalação das Dependências

Após adicionar as dependências, execute:

```bash
flutter pub get
```

## Notas Importantes

1. **Testes de Serviços**: Alguns testes de serviços requerem mocks completos do Supabase. Os testes foram estruturados com comentários indicando onde os mocks devem ser implementados.

2. **Testes de Widgets**: Os testes de widgets são mais completos e podem ser executados diretamente, pois não dependem de serviços externos.

3. **Testes de Helpers**: Os testes de helpers (ThemeHelper, TextStyleHelper, etc.) são testes puros e podem ser executados sem dependências externas.

## Estrutura de um Teste

```dart
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('NomeDoComponente', () {
    test('descrição do teste', () {
      // Arrange
      // Act
      // Assert
    });
  });
}
```

## Próximos Passos

Para melhorar a cobertura de testes:

1. Implementar mocks completos para os serviços Supabase
2. Adicionar testes de integração
3. Adicionar testes de performance
4. Configurar CI/CD para executar testes automaticamente

