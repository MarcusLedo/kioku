import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:kioku/services/supabase_service.dart';

class MockSupabaseClient extends Mock implements SupabaseClient {}

void main() {
  group('SupabaseService', () {
    test('deve retornar a mesma instância (singleton)', () {
      final instance1 = SupabaseService.instance;
      final instance2 = SupabaseService.instance;
      
      expect(instance1, equals(instance2));
    });

    test('deve ter um cliente Supabase', () {
      // Nota: Este teste requer que o Supabase esteja inicializado
      // Em um ambiente de teste real, você mockaria o cliente
      final service = SupabaseService.instance;
      expect(service.client, isNotNull);
    });
  });
}

