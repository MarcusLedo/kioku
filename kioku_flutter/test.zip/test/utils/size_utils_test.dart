import 'package:flutter/cupertino.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kioku/core/utils/size_utils.dart';

void main() {
  group('ResponsiveExtension', () {
    test('deve calcular h corretamente', () {
      // Nota: Este teste requer que SizeUtils.width esteja inicializado
      // Em um ambiente real, você inicializaria o SizeUtils antes do teste
    });

    test('deve calcular fSize corretamente', () {
      // Nota: Este teste requer que SizeUtils.width esteja inicializado
    });
  });

  group('FormatExtension', () {
    test('toDoubleValue deve formatar corretamente', () {
      const value = 3.14159;
      final formatted = value.toDoubleValue(fractionDigits: 2);
      
      expect(formatted, closeTo(3.14, 0.01));
    });

    test('isNonZero deve retornar valor quando maior que zero', () {
      const value = 5.0;
      final result = value.isNonZero(defaultValue: 0.0);
      
      expect(result, equals(5.0));
    });

    test('isNonZero deve retornar defaultValue quando zero ou negativo', () {
      const value = 0.0;
      const defaultValue = 10.0;
      final result = value.isNonZero(defaultValue: defaultValue);
      
      expect(result, equals(defaultValue));
    });

    test('isNonZero deve retornar defaultValue quando negativo', () {
      const value = -5.0;
      const defaultValue = 10.0;
      final result = value.isNonZero(defaultValue: defaultValue);
      
      expect(result, equals(defaultValue));
    });
  });

  group('SizeUtils', () {
    test('setScreenSize deve configurar width e height corretamente em portrait', () {
      final constraints = BoxConstraints(
        maxWidth: 430,
        maxHeight: 932,
      );
      
      SizeUtils.setScreenSize(constraints, Orientation.portrait);
      
      expect(SizeUtils.width, equals(430.0));
      expect(SizeUtils.height, equals(932.0));
      expect(SizeUtils.orientation, Orientation.portrait);
    });

    test('setScreenSize deve configurar width e height corretamente em landscape', () {
      final constraints = BoxConstraints(
        maxWidth: 932,
        maxHeight: 430,
      );
      
      SizeUtils.setScreenSize(constraints, Orientation.landscape);
      
      expect(SizeUtils.width, equals(430.0));
      expect(SizeUtils.height, equals(932.0));
      expect(SizeUtils.orientation, Orientation.landscape);
    });

    test('deviceType deve ser mobile', () {
      final constraints = BoxConstraints(
        maxWidth: 430,
        maxHeight: 932,
      );
      
      SizeUtils.setScreenSize(constraints, Orientation.portrait);
      
      expect(SizeUtils.deviceType, DeviceType.mobile);
    });
  });
}

