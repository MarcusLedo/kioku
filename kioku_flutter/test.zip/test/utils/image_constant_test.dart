import 'package:flutter_test/flutter_test.dart';
import 'package:kioku/core/utils/image_constant.dart';

void main() {
  group('ImageConstant', () {
    test('deve ter imgPlaceholder definido', () {
      expect(ImageConstant.imgPlaceholder, isNotEmpty);
      expect(ImageConstant.imgPlaceholder, contains('assets/images/'));
    });

    test('deve ter imgVector definido', () {
      expect(ImageConstant.imgVector, isNotEmpty);
      expect(ImageConstant.imgVector, contains('assets/images/'));
      expect(ImageConstant.imgVector, endsWith('.svg'));
    });

    test('deve ter imgImageNotFound definido', () {
      expect(ImageConstant.imgImageNotFound, isNotEmpty);
      expect(ImageConstant.imgImageNotFound, contains('assets/images/'));
      expect(ImageConstant.imgImageNotFound, endsWith('.png'));
    });

    test('todas as imagens devem começar com assets/images/', () {
      expect(ImageConstant.imgPlaceholder, startsWith('assets/images/'));
      expect(ImageConstant.imgVector, startsWith('assets/images/'));
      expect(ImageConstant.imgImageNotFound, startsWith('assets/images/'));
    });
  });
}

