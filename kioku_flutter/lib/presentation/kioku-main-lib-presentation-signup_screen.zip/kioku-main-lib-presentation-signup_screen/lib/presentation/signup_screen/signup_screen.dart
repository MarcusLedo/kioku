import 'package:flutter/material.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_edit_text.dart';
import '../../widgets/custom_image_view.dart';
import './controller/signup_controller.dart';

class SignupScreen extends GetWidget<SignupController> {
  SignupScreen({Key? key}) : super(key: key);

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.cyan_A700,
      body: Form(
        key: _formKey,
        child: Container(
          width: double.infinity,
          height: double.infinity,
          padding: EdgeInsets.only(top: 60.h),
          child: SingleChildScrollView(
            child: Column(
              spacing: 60.h,
              children: [
                _buildKiokuIcon(),
                _buildSignupCard(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildKiokuIcon() {
    return CustomImageView(
      imagePath: ImageConstant.imgVector,
      width: 152.h,
      height: 136.h,
    );
  }

  Widget _buildSignupCard() {
    return Container(
      width: 280.h,
      decoration: BoxDecoration(
        color: appTheme.gray_50,
        borderRadius: BorderRadius.circular(32.h),
      ),
      padding: EdgeInsets.symmetric(horizontal: 30.h, vertical: 14.h),
      child: Column(
        children: [
          _buildSignupTitle(),
          _buildEmailField(),
          _buildNameField(),
          _buildPhoneField(),
          _buildPasswordField(),
          _buildConfirmPasswordField(),
          _buildSignupButton(),
          SizedBox(height: 10.h),
        ],
      ),
    );
  }

  Widget _buildSignupTitle() {
    return Container(
      margin: EdgeInsets.only(top: 6.h),
      child: Text(
        "CADASTRO",
        style: TextStyleHelper.instance.title20BoldOpenSans,
      ),
    );
  }

  Widget _buildEmailField() {
    return Container(
      margin: EdgeInsets.only(top: 10.h, left: 2.h),
      child: Column(
        spacing: 4.h,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "E-mail",
            style: TextStyleHelper.instance.body15RegularOpenSans,
          ),
          CustomEditText(
            controller: controller.emailController,
            hintText: "Digite seu e-mail",
            keyboardType: TextInputType.emailAddress,
            validator: null,
          ),
        ],
      ),
    );
  }

  Widget _buildNameField() {
    return Container(
      margin: EdgeInsets.only(top: 8.h, left: 2.h),
      child: Column(
        spacing: 4.h,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Nome",
            style: TextStyleHelper.instance.body15RegularOpenSans,
          ),
          CustomEditText(
            controller: controller.nameController,
            hintText: "Digite seu nome",
            validator: null,
          ),
        ],
      ),
    );
  }

  Widget _buildPhoneField() {
    return Container(
      margin: EdgeInsets.only(top: 8.h, left: 2.h),
      child: Column(
        spacing: 4.h,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Telefone",
            style: TextStyleHelper.instance.body15RegularOpenSans,
          ),
          CustomEditText(
            controller: controller.phoneController,
            hintText: "Digite seu telefone",
            keyboardType: TextInputType.phone,
            validator: null,
          ),
        ],
      ),
    );
  }

  Widget _buildPasswordField() {
    return Container(
      margin: EdgeInsets.only(top: 8.h, left: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Senha",
            style: TextStyleHelper.instance.body15RegularOpenSans,
          ),
          SizedBox(height: 4.h),
          Obx(() => CustomEditText(
                controller: controller.passwordController,
                hintText: "Digite sua senha",
                keyboardType: TextInputType.visiblePassword,
                obscureText: !controller.obscurePassword.value,
                validator: null,
                suffixIcon: IconButton(
                  icon: Icon(
                    controller.obscurePassword.value
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: appTheme.cyan_900,
                    size: 20.h,
                  ),
                  onPressed: controller.togglePasswordVisibility,
                ),
              )),
        ],
      ),
    );
  }

  Widget _buildConfirmPasswordField() {
    return Container(
      margin: EdgeInsets.only(top: 8.h, left: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Confirmar Senha",
            style: TextStyleHelper.instance.body15RegularOpenSans,
          ),
          SizedBox(height: 4.h),
          Obx(() => CustomEditText(
                controller: controller.confirmPasswordController,
                hintText: "Digite sua senha novamente",
                keyboardType: TextInputType.visiblePassword,
                obscureText: !controller.obscureConfirmPassword.value,
                validator: null,
                suffixIcon: IconButton(
                  icon: Icon(
                    controller.obscureConfirmPassword.value
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: appTheme.cyan_900,
                    size: 20.h,
                  ),
                  onPressed: controller.toggleConfirmPasswordVisibility,
                ),
              )),
        ],
      ),
    );
  }

  Widget _buildSignupButton() {
    return Obx(() => CustomButton(
          text: "Cadastrar",
          width: 130.h,
          onPressed: controller.isLoading.value
              ? null
              : () => controller.onSignUpTap(),
          margin: EdgeInsets.only(top: 14.h),
        ));
  }
}