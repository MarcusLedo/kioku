import '../../../core/app_export.dart';

class SignupModel {
  Rx<String>? email = Rx('');
  Rx<String>? name = Rx('');
  Rx<String>? phone = Rx('');
  Rx<String>? password = Rx('');
}
